package mancala;

public class Main {

	public static void main(String[] args) {
		
		
		Board game = new Board();
		//initializes game
		game.initialize();
		//game starts
		game.start();

	}

}
